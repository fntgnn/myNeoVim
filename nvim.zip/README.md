# NeoVim

My neoVim configuration with basic plugins:
* Emmet
* nerdcommenter
* nerdtree
* vim-airline
* vim-figitive
